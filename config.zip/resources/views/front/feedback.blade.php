<!-- resources/views/front/feedback.blade.php -->

<p><strong>Name:</strong> {{ $name }}</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Message:</strong></p>
<p>{{ $messageContent }}</p>
