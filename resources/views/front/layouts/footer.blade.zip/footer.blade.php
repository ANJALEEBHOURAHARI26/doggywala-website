<footer class="footer py-5" style="background-color: #A8DF8E;">
    <div class="container">
        <div class="row text-dark">
            <!-- About -->
            <div class="col-md-3 mb-4">
                <h5 class="fw-bold">Doggywala</h5>
                <p>Find your perfect dog buddy. We connect dog lovers with responsible breeders and adoption centers.</p>
            </div>

            <!-- Quick Links -->
            <div class="col-md-3 mb-4">
                <h5 class="fw-bold">Quick Links</h5>
                <ul class="list-unstyled">
                    <li><a href="{{ route('home') }}" class="text-dark text-decoration-none">Home</a></li>
                    <li><a href="#" class="text-dark text-decoration-none">Available Puppies</a></li>
                    <li><a href="#" class="text-dark text-decoration-none">Find Dogs</a></li>
                    <li><a href="#" class="text-dark text-decoration-none">Contact</a></li>
                </ul>
            </div>

            <div class="col-md-3 mb-4">
                <h5 class="fw-bold">PET LOVER</h5>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-dark text-decoration-none">Be a Pet Sitter</a></li>
                    <li><a href="#" class="text-dark text-decoration-none">Be a Dog Walker</a></li>
                    <li><a href="#" class="text-dark text-decoration-none">Premium Protection Coverage</a></li>
                    <li><a href="#" class="text-dark text-decoration-none">Rescue and Shelter Programme</a></li>
                </ul>
            </div>

            <!-- Contact Info -->
            <div class="col-md-3 mb-4">
                <h5 class="fw-bold">Contact Us</h5>
                <p>Email: support@doggywala.com</p>
                <p>Phone: +91 98765 43210</p>
                <p>Location: Indore, India</p>
            </div>

            <!-- Feedback Form -->
            <!-- <div class="col-md-3 mb-4">
                <h5 class="fw-bold">Leave a Message</h5>
                <form action="{{ route('sendFeedback') }}" method="POST">
                    @csrf
                    <div class="mb-2">
                        <input type="text" class="form-control form-control-sm" name="name" placeholder="Your Name" required>
                    </div>
                    <div class="mb-2">
                        <input type="email" class="form-control form-control-sm" name="email" placeholder="Your Email" required>
                    </div>
                    <div class="mb-2">
                        <textarea class="form-control form-control-sm" name="message" rows="2" placeholder="Message" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-success btn-sm">Send</button>
                </form>
            </div> -->
            
        </div>

        <hr class="text-dark" />
        <div class="text-center text-dark">
            &copy; {{ date('Y') }} Doggywala. All rights reserved.
        </div>
    </div>
</footer>
