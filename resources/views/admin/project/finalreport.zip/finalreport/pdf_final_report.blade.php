<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Final Report</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .header { text-align: center; font-size: 24px; font-weight: bold; }
        .section { margin-bottom: 20px; }
        .section h3 { font-size: 18px; text-decoration: underline; }
        .section p { font-size: 16px; }
        img { max-width: 100%; height: auto; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="header">Final Report</div>
    
    <div class="section">
        <h3>Title</h3>
        <p>{{ $title }}</p>
    </div>
    
    <div class="section">
        <h3>Date</h3>
        <p>{{ $date }}</p>
    </div>
    
    <div class="section">
        <h3>Description</h3>
        <p>{!! nl2br(e($description)) !!}</p>
    </div>
    
    <div class="section">
        <h3>Report One</h3>
        @if(filter_var($report_one, FILTER_VALIDATE_URL))
            <img src="{{ $report_one }}" alt="Report One">
        @else
            <p>{!! nl2br(e($report_one)) !!}</p>
        @endif
    </div>
    
    <div class="section">
        <h3>Report Two</h3>
        @if(filter_var($report_two, FILTER_VALIDATE_URL))
            <img src="{{ $report_two }}" alt="Report Two">
        @else
            <p>{!! nl2br(e($report_two)) !!}</p>
        @endif
    </div>
</body>
</html>
